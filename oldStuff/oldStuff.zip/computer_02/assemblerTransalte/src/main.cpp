#include <iostream>

int main()
{
    std::cout << "Hello Easy C++ project!" << std::endl;
    std::cin.ignore();
}
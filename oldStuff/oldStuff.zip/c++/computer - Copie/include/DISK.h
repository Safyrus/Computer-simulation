#ifndef DISK_H
#define DISK_H
#include <stdint.h>
#include <string>

class DISK
{
public:
    DISK();
    DISK(uint32_t length);
    DISK(char* s);
    virtual ~DISK();

    uint32_t getAdr();
    void setAdr(uint32_t a);
    void incAdr();
    int8_t getData();
    void setData(int8_t d);
    uint32_t length();
    void display(uint16_t x, uint16_t y, uint32_t page);

protected:

private:
    uint32_t adr;
    int8_t len;
    int8_t * data;
    uint32_t dataSize;

    void setLen();

    std::string regName[8] = {"A", "B", "C", "D", "E", "F", "R", "O"};
    std::string opName[256] =
    {
        "NOP","NXT","RST","OFF","ERO","RAN","","",
        "","","","","","","","",
        "MOV","MOV","GET","GET","SET","SET","ADR","ADR",
        "GO" ,"GO" ,"DEV","","","","","",
        "AJC","AJZ","AJV","AJN","AJI","AJE","AJG","AJL",
        "AJP","","","","","","","",
        "IFC","IFZ","IFV","IFN","IFI","IFE","IFG","IFL",
        "JMP","","","","","","","",
        "ADD","ADD","SUB","SUB","MUL","MUL","DIV","DIV",
        "MOD","MOD","INC","DEC","","","","",
        "AND","AND","OR" ,"OR" ,"XOR","XOR","NOT","SHR",
        "SHR","SHL","SHL","","","","","",
        "CMP","CMP","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","",""
    };
};

#endif // DISK_H

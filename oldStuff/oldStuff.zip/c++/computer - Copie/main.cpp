#include <SDL.h>
#include <iostream>
#include <stdio.h>
#include <time.h>

#include "Computer.h"
#include "Keyboard.h"
#include "Screen.h"
#include "global.h"
#include "windows.h"
#include "../ansi_escape.h"


SDL_Window* win = NULL;
SDL_Renderer* render = NULL;
bool quit = false;
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

SDL_Event e;
bool keys[10] {false};
enum keysName { key_up, key_down, key_left, key_right};

Computer *com = new Computer("jump.a");
Keyboard *keyboard = new Keyboard();
Screen *screen = new Screen();

uint32_t fps = 0;
uint32_t timer = 0;
uint32_t Hz = 20;
uint32_t timerHz = 0;
uint32_t counterHz = 0;
uint32_t maxFps = 20;

bool init()
{
    srand (time(NULL));
    //Initialization flag
    bool success = true;

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Set texture filtering to linear
        if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
        {
            printf( "Warning: Linear texture filtering not enabled!" );
        }

        //Create window
        win = SDL_CreateWindow( "8-bit Computer", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( win == NULL )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Create renderer for window
            render = SDL_CreateRenderer( win, -1, SDL_RENDERER_ACCELERATED );
            if( render == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( render, 0xFF, 0xFF, 0xFF, 0xFF );
            }
        }
    }
    return success;
}

void close()
{
    SDL_DestroyRenderer( render );
    SDL_DestroyWindow( win );
    win = NULL;
    render = NULL;

    delete com;
    //delete keyboard;
    //delete screen;

    SDL_Quit();
}

void event()
{
    while( SDL_PollEvent( &e ) != 0 )
    {
        if( e.type == SDL_QUIT )
        {
            quit = true;
        }
        else if( e.type == SDL_KEYDOWN )
        {
            switch( e.key.keysym.sym )
            {
            case SDLK_UP:
                keys[key_up] = true;
                break;
            case SDLK_DOWN:
                keys[key_down] = true;
                break;
            case SDLK_LEFT:
                keys[key_left] = true;
                break;
            case SDLK_RIGHT:
                keys[key_right] = true;
                break;
            default:
                keyboard->setData(e.key.keysym.sym);
                break;
            }
        }
        else if( e.type == SDL_KEYUP )
        {
            switch( e.key.keysym.sym )
            {
            case SDLK_UP:
                keys[key_up] = false;
                refresh = true;
                break;
            case SDLK_DOWN:
                keys[key_down] = false;
                refresh = true;
                break;
            case SDLK_LEFT:
                keys[key_left] = false;
                refresh = true;
                break;
            case SDLK_RIGHT:
                keys[key_right] = false;
                refresh = true;
                break;
            default:
                break;
            }
        }
    }
}

void key()
{
    if(keys[key_down])
    {
        //Render red filled quad
        SDL_Rect fillRect = { SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 };
        SDL_SetRenderDrawColor( render, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderFillRect( render, &fillRect );
        refresh = true;
    }
    else if(keys[key_left])
    {
        //Render green outlined quad
        SDL_Rect outlineRect = { SCREEN_WIDTH / 6, SCREEN_HEIGHT / 6, SCREEN_WIDTH * 2 / 3, SCREEN_HEIGHT * 2 / 3 };
        SDL_SetRenderDrawColor( render, 0x00, 0xFF, 0x00, 0xFF );
        SDL_RenderDrawRect( render, &outlineRect );
        refresh = true;
    }
    else if(keys[key_right])
    {
        //Draw blue horizontal line
        SDL_SetRenderDrawColor( render, 0x00, 0x00, 0xFF, 0xFF );
        SDL_RenderDrawLine( render, 0, SCREEN_HEIGHT / 2, SCREEN_WIDTH, SCREEN_HEIGHT / 2 );
        refresh = true;
    }
    else if(keys[key_up])
    {
        //Draw vertical line of yellow dots
        SDL_SetRenderDrawColor( render, 0xFF, 0xFF, 0x00, 0xFF );
        for( int i = 0; i < SCREEN_HEIGHT; i += 4 )
        {
            SDL_RenderDrawPoint( render, SCREEN_WIDTH / 2, i );
        }
        refresh = true;
    }
}

int main(int argc, char **argv)
{
    if(!init())
    {
        return -1;
        printf( "Failed to initialize!\n" );
    }

    SetWindow(118, 40);
    setupConsole();

    //puts("\x1b[31m\x1b[44mHello, World");
    printf("\x1b[97m\x1b[102m");
    printf("|start simulation|");
    printf("\x1b[0m\n");

    com->add_device(keyboard, 0);
    com->add_device(screen, 1);
    com->power();

    if(maxFps == 0)
    {
        maxFps = 1;
    }
    if(maxFps > Hz)
    {
        maxFps = Hz;
    }

    //Clear screen
    SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
    SDL_RenderClear(render);

    while(!quit)
    {
        event();
        key();

        if(refresh)
        {
            //Update screen
            SDL_RenderPresent(render);
            refresh = false;

            //Clear screen
            SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
            SDL_RenderClear(render);
        }

        if(SDL_GetTicks() - timerHz > 1000/maxFps)
        {
            timerHz = SDL_GetTicks();
            for(int i=0; i<Hz/maxFps; i++)
            {
                com->tick();
                com->display(render, 0, 0);
                refresh = true;
                counterHz++;
            }
        }
        if(SDL_GetTicks() - timer > 1000)
        {
            timer = SDL_GetTicks();
            printf("\x1b[94m\x1b[49m");
            printf("fps: %u, time:%u, Hz:%u", fps, timer, counterHz);
            printf("\x1b[0m\n");
            fps = 0;
            counterHz = 0;
        }
        else
        {
            fps++;
        }
    }

    if(print)
        printf("\x1b[97m\x1b[102m|end simulation|");
    printf("\x1b[0m\n");
    close();
    restoreConsole();
    return 0;
}

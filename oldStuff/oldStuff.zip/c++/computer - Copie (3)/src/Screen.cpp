#include "Screen.h"
#include "../global.h"
#include <stdint.h>
#include <stdio.h>
#include <SDL.h>

Screen::Screen()
{
    if(print)
        printf("Screen: create...\n");
    resX = 32;
    resY = 32;
    data = new uint8_t*[resX];
    for (int i=0; i<resX; i++)
        data[i] = new uint8_t[resY];
    for(int i=0; i<resX; i++)
        for(int j=0; j<resY; j++)
            data[i][j] = 0;
    data[0][0] = 1;
    data[0][2] = 1;
    data[2][0] = 1;
    data[2][2] = 1;
    drawRatio = 10;
    cache[0] = 0;
    cache[1] = 0;
    cacheCnt = 0;
    mode = 0;
    refresh = false;
    if(print)
        printf("Screen: created\n");
}

Screen::~Screen()
{
    for (int i=0; i <resX; i++)
        delete[] data[i];
    delete[] data;
    if(print)
        printf("Screen: destroyed\n");
}

void Screen::setData(int8_t d)
{
    switch(cacheCnt)
    {
    case 0:
    case 1:
        cache[cacheCnt] = d;
        cacheCnt++;
        break;
    case 2:
        if(cache[0] >= resX)
            cache[0] = resX-1;
        if(cache[0] >= resY)
            cache[0] = resY-1;
        data[cache[0]][cache[1]] = d;
        cacheCnt=0;
        break;
    }
}

int8_t Screen::getData()
{

}

void Screen::reset()
{
    for(int i=0; i<resX; i++)
        for(int j=0; j<resY; j++)
            data[i][j] = 0;
}

int8_t Screen::other(int8_t b)
{

}

void Screen::display(SDL_Renderer* render, uint16_t x, uint16_t y)
{
    for(int i=0; i<resX; i++)
    {
        for(int j=0; j<resY; j++)
        {
            switch(mode)
            {
            case 0:
                if(data[i][j] == 0)
                    SDL_SetRenderDrawColor(render, 0x00, 0x00, 0x00, 0xFF);
                else
                    SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
                break;
            }
            SDL_Rect fillRect = {x + (i*drawRatio), y + (j*drawRatio), drawRatio, drawRatio};
            SDL_RenderFillRect( render, &fillRect );
        }
    }
}

void Screen::printInfo()
{
    printf("Screen: res:%u/%u mode:%u refresh:%u ratio:%u cache:%u,%u cnt:%u\n", resX, resY, mode, refresh, drawRatio, cache[0], cache[1], cacheCnt);
}

#include "Computer.h"
#include "../global.h"
#include <SDL_ttf.h>

Computer::Computer()
{
    if(print)
        printf("COMPUTER: create...\n");
    run = false;
    cycle = 0;
    Hz = 4;
    fps = 4;
    cpu = new CPU();
    ram = new RAM(256);
    disk = new DISK("test.a");
    cpu->add_disk(disk);
    cpu->add_ram(ram);
    if(print)
        printf("COMPUTER: created\n");
}

Computer::Computer(char* s, uint32_t hz, int fps)
{
    if(print)
        printf("COMPUTER: create...\n");
    run = false;
    cycle = 0;
    Hz = hz;
    if(fps <= 0)
        this->fps = 1;
    else if(fps > Hz)
        this->fps = Hz;
    else
        this->fps = fps;
    cpu = new CPU();
    ram = new RAM(256);
    disk = new DISK(s);
    cpu->add_disk(disk);
    cpu->add_ram(ram);
    if(print)
        printf("COMPUTER: created\n");
}

Computer::~Computer()
{
    cpu->remove_disk();
    cpu->remove_ram();
    delete ram;
    delete disk;
    delete cpu;
    if(print)
        printf("COMPUTER: destroyed\n");
}


void Computer::power()
{
    run = !run;
    if(print)
    {
        printf("\x1b[93m\x1b[49m");
        printf("COMPUTER: power %s", (run)?"ON":"OFF");
        printf("\x1b[0m\n");
    }
    if(!run)
    {
        reset();
    }
}

bool Computer::isPower()
{
    return run;
}

void Computer::reset()
{
    cycle = 0;
    cpu->reset();
}

void Computer::tick()
{
    if(run)
    {
        for(int i=0; i<Hz/fps; i++)
        {
            cpu->tick();
            cycle++;
            int8_t e = cpu->getError();
            if(e <= 0)
            {
                if(e < 0 && print)
                {
                    printf("\x1b[91m\x1b[49m");
                    printf("COMPUTER: error %d at cycle %u", e, cycle);
                    printf("\x1b[0m\n");
                }
                if(printInfo)
                    printf("COMPUTER: tick %u\n", cycle);
            }
            else
            {
                if(e == 4)
                {
                    if(print)
                        printf("COMPUTER: stop at cycle %u\n", cycle);
                }
                else
                {
                    if(print)
                    {
                        printf("\x1b[97m\x1b[101m");
                        printf("COMPUTER: fatal error %d at cycle %u", e, cycle);
                        printf("\x1b[0m\n");
                    }
                }
                power();
                if(print)
                {
                    printf("\x1b[93m\x1b[49m");
                    printf("COMPUTER: power %s", (run)?"ON":"OFF");
                    printf("\x1b[0m\n");
                }
            }
        }
    }
}

void Computer::add_device(Device *d, uint8_t p)
{
    cpu->add_device(d, p);
}

void Computer::remove_device(uint8_t p)
{
    cpu->remove_device(p);
}

void Computer::display(SDL_Window* win, SDL_Renderer* render, uint16_t x, uint16_t y)
{
    cpu->display(render, x, y);

    float textRatio = 16;

    SDL_Rect fillRect = {x, y+380, 320, 132};
    SDL_SetRenderDrawColor(render, 0x88, 0x88, 0x88, 0xFF);
    SDL_RenderFillRect(render, &fillRect);

    TTF_Font* font = TTF_OpenFont("Perfect DOS VGA 437 Win.ttf", textRatio);
    SDL_Color color = {255, 255, 255};

    SDL_Rect msg_rect;
    SDL_Surface* text = NULL;
    SDL_Texture* msg = NULL;

    char s[50];
    uint32_t timer = SDL_GetTicks();
    sprintf(s, "power:%s", (run)?"ON":"OFF");

    text = TTF_RenderText_Solid(font, s, color);
    msg = SDL_CreateTextureFromSurface(render, text);
    msg_rect.x = x;
    msg_rect.y = y+400;
    msg_rect.w = text->w;
    msg_rect.h = text->h;

    SDL_RenderCopy(render, msg, NULL, &msg_rect);

    sprintf(s, "fps: %u, Hz:%u", fps, Hz);

    text = TTF_RenderText_Solid(font, s, color);
    msg = SDL_CreateTextureFromSurface(render, text);
    msg_rect.x = x;
    msg_rect.y = y+400+textRatio;
    msg_rect.w = text->w;
    msg_rect.h = text->h;

    SDL_RenderCopy(render, msg, NULL, &msg_rect);

    sprintf(s, "cycle:%u", cycle);

    text = TTF_RenderText_Solid(font, s, color);
    msg = SDL_CreateTextureFromSurface(render, text);
    msg_rect.x = x;
    msg_rect.y = y+400+textRatio+textRatio;
    msg_rect.w = text->w;
    msg_rect.h = text->h;

    SDL_RenderCopy(render, msg, NULL, &msg_rect);
}

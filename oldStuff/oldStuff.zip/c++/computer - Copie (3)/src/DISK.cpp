#include <stdint.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <iterator>
#include <vector>
#include <cmath>
#include <SDL.h>
#include <SDL_ttf.h>

#include "DISK.h"
#include "../global.h"

DISK::DISK()
{
    if(print)
        printf("DISK: create empty disk...\n");
    adr = 0;
    start = 0;
    dataSize = 1;
    data = new int8_t[dataSize];
    len = -1;
    if(print)
        printf("DISK: empty disk created\n");
}

DISK::DISK(uint32_t length)
{
    if(print)
        printf("DISK: create...\n");
    adr = 0;
    start = 0;
    dataSize = length;
    data = new int8_t[dataSize];
    for(uint32_t i=0; i<dataSize; i++)
        data[i] = i;
    setLen();
    if(print)
    {
        printf("DISK: info:\n");
        printf("  start:%i\n", adr);
        printf("  length:%i,%i\n",len,dataSize);
        printf("  data:");
        if(printFile)
        {
            for(uint32_t i=0; i<dataSize; i++)
            {
                if(i%16 == 0)
                    printf("\n");
                printf("%02X ", data[i] & 0xff);
            }
            printf("\n");
        }
    }
    if(print)
        printf("DISK: created\n");
}

bool is_number(const std::string& s)
{
    std::string::const_iterator it = s.begin();
    while (it != s.end() && std::isdigit(*it))
        ++it;
    return !s.empty() && it == s.end();
}

DISK::DISK(char* s)
{
    if(print)
        printf("DISK: create from file...\n");
    adr = 0;
    start = 0;
    len = 1;
    int ram = 1;
    dataSize = 256;
    data = new int8_t[dataSize];

    bool st = false;
    bool l = false;
    bool r = false;
    std::string str;
    std::vector<uint32_t> pos(0);
    std::vector<std::string> label(0);

    std::ifstream preFile(s);
    if (preFile.is_open())
    {
        if(printFile)
            printf("DISK_FILE: preRead file...\n");
        while(preFile >> str)
        {
            if(str.back() == ':')
            {
                if(!st && str.compare("START:") == 0)
                {
                    /*preFile >> str;
                    if(str.front() == '#')
                        go = std::stoul(str.substr(1, str.size()-1),nullptr,10);
                    else
                        go = std::stoul(str.substr(0, str.size()-1),nullptr,16);*/
                    start = adr;
                    if(printFile)
                        std::cout<< "  start found [" << start << "]\n";
                    st = true;
                }
                else if(!l && str.compare("LENGTH:") == 0)
                {
                    preFile >> str;
                    uint32_t length = 0;
                    if(str.front() == '#')
                        length = std::stoul(str.substr(1, str.size()-1),nullptr,10);
                    else
                        length = std::stoul(str.substr(0, str.size()-1),nullptr,16);
                    dataSize = length+1;
                    if(printFile)
                        std::cout<< "  length found [" << dataSize << "]\n";
                    data = new int8_t[dataSize];
                    setLen();
                    l = true;
                }
                else if(!r && str.compare("RAM:") == 0)
                {
                    preFile >> str;
                    ram = std::stoul(str.substr(0, str.size()-1),nullptr,10);
                    if(printFile)
                        std::cout<< "  ram found [" << ram << "]\n";
                    r = true;
                }
                else
                {
                    pos.push_back(adr);
                    std::string s = str;
                    s.erase(s.size()-1);
                    label.push_back(s);
                    if(printFile)
                        std::cout<< "  label " << label.back() << " find at " << pos.back() << '\n';
                }
            }
            else if(str.compare("/*") == 0)
            {
                int counter = 1;
                while(counter != 0 && preFile >> str)
                {
                    if(str.compare("*/") == 0)
                        counter--;
                    else if(str.compare("/*") == 0)
                        counter++;
                }
            }
            else
            {
                if(str.front() == '#' || str.front() == '$')
                {
                    std::cout << str << " " << adr <<"\n";
                    adr++;
                }
                else
                {
                    if(str.back() != '-')
                    {
                        bool cmd = false;
                        for(int i=0; i<256; i++)
                        {
                            if(str.compare(opName[i]) == 0)
                            {
                                std::cout << str << " " << adr << "\n";
                                if(i >= 0x12 && i <= 0x15 || (i >= 0x20 && i <= 0x38))
                                {
                                    adr+=len;
                                    preFile >> str;
                                }
                                else if(i == 0x16 || i == 0x17)
                                {
                                    adr+=ram;
                                    preFile >> str;
                                }
                                cmd=true;
                                adr++;
                                break;
                            }
                        }
                        if(!cmd)
                        {
                            std::cout << str << " " << adr <<"\n";
                            adr++;
                        }
                    }
                }
            }
        }
    }
    else
    {
        if(printFile)
            printf("DISK_FILE: Failed to open file\n");
    }

    if(printFile)
        printf("DISK_FILE: size: %u\n", adr);
    adr = 0;
    preFile.close();
    std::ifstream file(s);
    if (file.is_open())
    {
        if(printFile)
            printf("DISK_FILE: read file...\n");
        while(file >> str)
        {
            if(str.compare("/*") == 0)
            {
                if(printFile)
                    printf("  commentary:\n");
                int counter = 1;
                while(counter != 0 && file >> str)
                {
                    if(str.compare("*/") == 0)
                        counter--;
                    else if(str.compare("/*") == 0)
                        counter++;
                    else if(printFile)
                    {
                        for(int i=0; i<counter; i++)
                            std::cout<< "  ";
                        std::cout<< "  " << str << '\n';
                    }
                }
            }
            else if(str.back() == ':' || str.back() == '-')
            {
                std::cout<< "  " << str << '\n';
            }
            else
            {
                if(printFile)
                    std::cout<< "  " << str;

                bool cmd = false;
                for(int i=0; i<256; i++)
                {
                    if(str.compare(opName[i]) == 0)
                    {
                        if(i >= 0x20 && i < 0x40)
                        {
                            if(printFile)
                                printf("  conditionnal command found\n  ");
                            data[adr] = i;
                            file >> str;
                            if(printFile)
                                std::cout<< "  " << str;
                            for(int j=0; j<label.size(); j++)
                            {
                                if(str.compare(label.at(j)) == 0)
                                {
                                    if(printFile)
                                        std::cout<< "  label " << label.at(j) << "(" << pos.at(j) << ")" << " retreive at " << adr+1 << '\n';
                                    uint32_t jp = pos.at(j)-adr;
                                    if(jp>dataSize)
                                    {
                                        jp %= dataSize;
                                    }
                                    switch(len)
                                    {
                                    case 1:
                                        if(i >= 0x20 && i < 0x30)
                                        {
                                            data[adr+1] = pos.at(j) & 0xff;
                                        }
                                        else
                                        {
                                            data[adr+1] = jp;
                                        }
                                        break;
                                    case 2:
                                        if(i >= 0x20 && i < 0x30)
                                        {
                                            data[adr+1] = pos.at(j) & 0xff00;
                                            data[adr+2] = pos.at(j) & 0xff;
                                        }
                                        else
                                        {
                                            data[adr+1] = jp >> 8;
                                            data[adr+2] = jp;
                                        }
                                        break;
                                    case 3:
                                        if(i >= 0x20 && i < 0x30)
                                        {
                                            data[adr+1] = pos.at(j) & 0xff0000;
                                            data[adr+2] = pos.at(j) & 0xff00;
                                            data[adr+3] = pos.at(j) & 0xff;
                                        }
                                        else
                                        {
                                            data[adr+1] = (pos.at(j)-adr) & 0xff0000;
                                            data[adr+2] = (pos.at(j)-adr) & 0xff00;
                                            data[adr+3] = (pos.at(j)-adr) & 0xff;
                                        }
                                        break;
                                    case 4:
                                        if(i >= 0x20 && i < 0x30)
                                        {
                                            data[adr+1] = pos.at(j) & 0xff000000;
                                            data[adr+2] = pos.at(j) & 0xff0000;
                                            data[adr+3] = pos.at(j) & 0xff00;
                                            data[adr+4] = pos.at(j) & 0xff;
                                        }
                                        else
                                        {
                                            data[adr+1] = (pos.at(j)-adr) & 0xff000000;
                                            data[adr+2] = (pos.at(j)-adr) & 0xff0000;
                                            data[adr+3] = (pos.at(j)-adr) & 0xff00;
                                            data[adr+4] = (pos.at(j)-adr) & 0xff;
                                        }
                                        break;
                                    }
                                    adr += len+1;
                                    break;
                                }
                            }
                            cmd = true;
                            break;
                        }
                        else if( i == 0x10 || i == 0x11 || (i >= 0x40 && i <= 0x49) || (i >= 0x50 && i <= 0x55) || (i >= 0x57 && i <= 0x61))
                        {
                            if(printFile)
                                printf("  multiple command possible\n");
                            file >> str;
                            if(printFile)
                                std::cout<< "  " << str;
                            if(printFile)
                                printf("  reg found\n");
                            for(int j=0; j<8; j++)
                            {
                                if(str.substr(1) == regName[j])
                                {
                                    data[adr+1] = j;
                                    break;
                                }
                            }
                            file >> str;
                            if(printFile)
                                std::cout<< "  " << str;
                            if(str.front() == '$')
                            {
                                if(printFile)
                                    printf("  reg found\n");
                                for(int j=0; j<8; j++)
                                {
                                    if(str.substr(1) == regName[j])
                                    {
                                        data[adr+2] = j;
                                        break;
                                    }
                                }
                                data[adr] = i;
                            }
                            else
                            {
                                if(str.front() == '#')
                                {
                                    if(printFile)
                                        printf("  decimal found\n");
                                    data[adr+2] = std::stoul(str.substr(1),nullptr,10);
                                }
                                else
                                {
                                    if(printFile)
                                        printf("  hex found\n");
                                    data[adr+2] = std::stoul(str,nullptr,16);
                                }
                                data[adr] = i+1;
                            }
                            adr += 3;
                            cmd = true;
                            break;
                        }
                        else if(i >= 0x12 && i <= 0x19)
                        {
                            if(printFile)
                                printf("  adresse command found\n  ");
                            file >> str;
                            int b = len;
                            if(i >= 0x16 && i <= 0x19)
                                b = ram;
                            uint32_t a=0;
                            if(str.front() == '$')
                            {
                                data[adr] = i;
                                if(printFile)
                                    printf("  reg found\n");
                                for(int j=b; j>0; j--)
                                {
                                    std::string s = str.substr(str.size()-b+j-1,1);
                                    if(s == "")
                                        break;
                                    for(int k=0; k<8; k++)
                                    {
                                        if(regName[k] == s)
                                        {
                                            a += k*pow(256, b-j);
                                            //std::cout << s << " " << k << " " << a << " " << pow(256, b-j);
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                data[adr] = i+1;
                                if(str.front() == '#')
                                {
                                    if(printFile)
                                        printf("  decimal found\n");
                                    str = str.substr(1);
                                    a = std::stoul(str,nullptr,10);
                                }
                                else
                                {
                                    if(printFile)
                                        printf("  hex found\n");
                                    a = std::stoul(str,nullptr,16);
                                }
                            }
                            switch(b)
                            {
                            case 1:
                                data[adr+1] = a & 0xff;
                                break;
                            case 2:
                                data[adr+1] = a & 0xff00;
                                data[adr+2] = a & 0xff;
                                break;
                            case 3:
                                data[adr+1] = a & 0xff0000;
                                data[adr+2] = a & 0xff00;
                                data[adr+3] = a & 0xff;
                                break;
                            case 4:
                                data[adr+1] = a & 0xff000000;
                                data[adr+2] = a & 0xff0000;
                                data[adr+3] = a & 0xff00;
                                data[adr+4] = a & 0xff;
                                break;
                            }
                            adr += b+1;
                            if(i >= 0x12 && i <= 0x15)
                            {
                                file >> str;
                                if(str.front() == '$')
                                {
                                    if(printFile)
                                        printf("  reg found\n");
                                    for(int i=0; i<8; i++)
                                    {
                                        if(str.substr(1) == regName[i])
                                        {
                                            data[adr] = i;
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    if(printFile)
                                        printf("  ERROR: reg not found\n");
                                }
                                adr++;
                            }
                            cmd = true;
                            break;
                        }
                        else
                        {
                            if(printFile)
                                printf("  unique command found\n");
                            data[adr] = i;
                            adr++;
                            cmd = true;
                            break;
                        }
                    }
                }
                if(!cmd)
                {
                    if(str.front() == '$')
                    {
                        if(printFile)
                            printf("  reg found\n");
                        for(int i=0; i<8; i++)
                        {
                            if(str.substr(1) == regName[i])
                            {
                                data[adr] = i;
                                break;
                            }
                        }
                    }
                    else if(str.front() == '#')
                    {
                        if(printFile)
                            printf("  decimal found\n");
                        data[adr] = std::stoul(str.substr(1),nullptr,10);
                    }
                    else
                    {
                        if(printFile)
                            printf("  hex found\n");
                        data[adr] = std::stoul(str,nullptr,16);
                    }
                    adr++;
                }
            }
        }
        file.close();
        if(print)
            printf("DISK_FILE: size: %u\n", adr);
        adr = start;
        if(printFile)
        {
            printf("DISK_FILE: file load:\n");
            printf("  start: %u\n", adr);
            printf("  length: %i,%u\n",len,dataSize);
            printf("  data:");
            int cnt = 0;
            for(uint32_t i=0; i<dataSize; i++)
            {
                if(i%256 == 0)
                {
                    printf("\n\n     00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F");
                    printf(  "\n     -----------------------------------------------");
                    cnt=0;
                }
                if(i%16 == 0)
                {
                    printf("\n %X0|",cnt);
                    cnt++;
                }
                printf(" %02X", data[i] & 0xff);
            }
            printf("\n");
        }
    }
    else
    {
        if(print)
            printf("DISK_FILE: Failed to load file in disk\n");
        dataSize = 1;
        data = new int8_t[dataSize];
    }
    if(print)
        printf("DISK: created\n");
}

DISK::~DISK()
{
    delete data;
    if(print)
        printf("DISK: destroyed\n");
}

void DISK::display(SDL_Renderer* render, uint16_t x, uint16_t y, uint32_t page)
{
    uint32_t p = page*256;

    float textRatio = 16;

    SDL_SetRenderDrawColor(render, 0x00, 0x00, 0xFF, 0xFF);
    SDL_Rect background = {x, y, 16*textRatio*1.4, 16*textRatio+20};
    SDL_RenderFillRect( render, &background );

    TTF_Font* font = TTF_OpenFont("Perfect DOS VGA 437 Win.ttf", textRatio);
    SDL_Color color = {255, 255, 255};

    SDL_Rect msg_rect;
    SDL_Surface* text = NULL;
    SDL_Texture* msg = NULL;

    char s[30];
    sprintf(s, "DISK:    PAGE:%X02    OPCODE:%s", p & 0xff, getCmd(data[adr]).c_str());

    text = TTF_RenderText_Solid(font, s, color);
    msg = SDL_CreateTextureFromSurface(render, text);
    msg_rect.x = x;
    msg_rect.y = y;
    msg_rect.w = text->w;
    msg_rect.h = text->h;

    SDL_RenderCopy(render, msg, NULL, &msg_rect);

    y += 20;

    for(uint32_t i=p; i<p+256; i+=16)
    {
        for(uint32_t j=i; j<i+16; j++)
        {
            sprintf(s, "%02X", data[j] & 0xff);

            text = TTF_RenderText_Solid(font, s, color);
            if(j == adr)
            {
                SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
                SDL_Rect rect = {x+((j%16)*(textRatio*1.4)), y+((i%256)*(textRatio/16)), text->w, text->h};
                SDL_RenderFillRect( render, &rect );
                color = {0,0,255};
            }
            else
                color = {255,255,255};
            text = TTF_RenderText_Solid(font, s, color);
            msg = SDL_CreateTextureFromSurface(render, text);
            msg_rect.x = x+((j%16)*(textRatio*1.4));
            msg_rect.y = y+((i%256)*(textRatio/16));
            msg_rect.w = text->w;
            msg_rect.h = text->h;

            SDL_RenderCopy(render, msg, NULL, &msg_rect);
        }
    }

    TTF_CloseFont(font);
    font = NULL;
}

uint32_t DISK::getAdr()
{
    return adr;
}

void DISK::setAdr(uint32_t a)
{
    adr = a;
}

void DISK::incAdr()
{
    adr++;
}

int8_t DISK::getData()
{
    return data[adr];
}

void DISK::setData(int8_t d)
{
    //*(data+adr) = d;
    data[adr] = d;
}

uint32_t DISK::length()
{
    return len;
}

void DISK::setLen()
{
    if(dataSize <= 256)
        len = 1;
    else if(dataSize <= 65536)
        len = 2;
    else if(dataSize <= 16777216)
        len = 3;
    else
        len = 4;
}

void DISK::reset()
{
    adr = start;
}

uint32_t DISK::getDataSize()
{
    return dataSize;
}

std::string DISK::getCmd(int8_t cmd)
{
    return opName[cmd];
}

#include <stdint.h>
#include <stdio.h>
#include <SDL.h>
#include <SDL_ttf.h>

#include "RAM.h"
#include "../global.h"

RAM::RAM()
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = 256;
    len = 1;
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created\n");
}

RAM::RAM(uint32_t length)
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = length;
    setLen();
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created, bytes_length: %d\n", len);
}

RAM::~RAM()
{
    delete data;
    if(print)
        printf("RAM: destroyed\n");
}


uint32_t RAM::getAdr()
{
    return adr;
}

void RAM::setAdr(uint32_t a)
{
    adr = a;
}

int8_t RAM::getData()
{
    return data[adr];
}

void RAM::setData(int8_t d)
{
    data[adr] = d;
}

uint32_t RAM::length()
{
    return len;
}

void RAM::setLen()
{
    if(dataSize <= 256)
        len = 1;
    else if(dataSize <= 65536)
        len = 2;
    else if(dataSize <= 16777216)
        len = 3;
    else
        len = 4;
}

void RAM::incAdr()
{
    adr++;
}

void RAM::reset()
{
    adr = 0;
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
}

void RAM::display(SDL_Renderer* render, uint16_t x, uint16_t y, uint32_t page)
{
    uint32_t p = page*256;

    float textRatio = 16;

    SDL_SetRenderDrawColor(render, 0xFF, 0x00, 0x00, 0xFF);
    SDL_Rect background = {x, y, 16*textRatio*1.4, 16*textRatio+20};
    SDL_RenderFillRect( render, &background );

    TTF_Font* font = TTF_OpenFont("Perfect DOS VGA 437 Win.ttf", textRatio);
    SDL_Color color = {0, 0, 0};

    SDL_Rect msg_rect;
    SDL_Surface* text = NULL;
    SDL_Texture* msg = NULL;

    for(uint32_t i=p; i<p+256; i+=16)
    {
        for(uint32_t j=i; j<i+16; j++)
        {
            char s[3];
            sprintf(s, "%02X", data[p+j] & 0xff);

            text = TTF_RenderText_Solid(font, s, color);
            if(p+j == adr)
            {
                SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
                SDL_Rect rect = {x+((j%16)*(textRatio*1.4)), y+(i*(textRatio/16)), text->w, text->h};
                SDL_RenderFillRect( render, &rect );
                color = {255,0,0};
            }
            else
                color = {255,255,255};
            text = TTF_RenderText_Solid(font, s, color);
            msg = SDL_CreateTextureFromSurface(render, text);
            msg_rect.x = x+((j%16)*(textRatio*1.4));
            msg_rect.y = y+(i*(textRatio/16));
            msg_rect.w = text->w;
            msg_rect.h = text->h;

            SDL_RenderCopy(render, msg, NULL, &msg_rect);
        }
    }

    TTF_CloseFont(font);
    font = NULL;
}

#ifndef COMPUTER_H
#define COMPUTER_H

#include "DISK.h"
#include "RAM.h"
#include "CPU.h"

class Computer
{
public:
    Computer();
    Computer(char* s, uint32_t hz, int fps);
    virtual ~Computer();

    void power();
    bool isPower();
    void reset();
    void tick();

    void add_device(Device *d, uint8_t p);
    void remove_device(uint8_t p);
    void display(SDL_Window* win, SDL_Renderer* render, uint16_t x, uint16_t y);

protected:

private:
    bool run;
    uint64_t cycle;
    uint64_t Hz;
    int fps;

    CPU *cpu;
    DISK *disk;
    RAM *ram;
};

#endif // COMPUTER_H

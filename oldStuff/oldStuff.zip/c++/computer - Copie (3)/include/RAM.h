#ifndef RAM_H
#define RAM_H
#include <stdint.h>
#include <SDL.h>


class RAM
{
public:
    RAM();
    RAM(uint32_t length);
    virtual ~RAM();

    uint32_t getAdr();
    void setAdr(uint32_t a);
    int8_t getData();
    void setData(int8_t d);
    uint32_t length();
    void incAdr();
    void reset();
    void display(SDL_Renderer* render, uint16_t x, uint16_t y, uint32_t page);

protected:

private:
    uint32_t adr;
    int8_t len;
    int8_t * data;
    uint32_t dataSize;

    void setLen();
};

#endif // RAM_H

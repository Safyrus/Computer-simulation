#ifndef CPU_H
#define CPU_H

#include <stdint.h>
#include <SDL.h>

#include "DISK.h"
#include "RAM.h"
#include "Device.h"

class CPU
{
public:
    CPU();
    CPU(char* file, uint32_t ram);
    CPU(DISK disk, RAM ram);
    virtual ~CPU();

    void tick();
    void reset();
    void add_disk(DISK *d);
    void remove_disk();
    void add_ram(RAM *r);
    void remove_ram();
    void add_device(Device *d, uint8_t p);
    void remove_device(uint8_t p);
    int8_t getError();
    void display(SDL_Renderer* render, uint16_t x, uint16_t y);

protected:

private:
    bool error;
    int8_t reg[8];
    //reg = A, B, C, D, E, FLAG, RAM, ERROR
    //CZVNUEGL
    //Carry, Zero, oVerflow, Negatif, Unsigned, Equal, Greater, Lesser

    DISK *disk;
    RAM *ram;
    Device *devices[8];

    int8_t CU(int8_t opcode);
    int8_t ALU(int8_t A, int8_t B, int8_t opcode);
    int8_t regOp(int8_t op);
    int8_t valOp(int8_t op);
    int8_t moveOp(int8_t a, int8_t b, int8_t op);
    int8_t oneOp(int8_t op);
    int8_t jump(int8_t op);
    int8_t err();
    int8_t device();
    int8_t diskOp(bool r, bool g);
    int8_t adr(bool r);
    int8_t go(bool r);
};

#endif // CPU_H

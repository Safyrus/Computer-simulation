#pragma once

void setupConsole(void);
void restoreConsole(void);
void SetWindow(int Width, int Height);

#ifndef DEVICE_H
#define DEVICE_H

#include <stdint.h>
#include <SDL.h>

class Device
{
public:
    Device();
    virtual ~Device()=0;
    virtual void setData(int8_t d)=0;
    virtual int8_t getData()=0;
    virtual void reset()=0;
    virtual int8_t other(int8_t b)=0;
    virtual void display(SDL_Renderer* render, uint16_t x, uint16_t y)=0;
    virtual void printInfo()=0;

protected:

private:
};

#endif // DEVICE_H

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>
#include <queue>
#include "Device.h"

class Keyboard: public Device
{
public:
    Keyboard();
    Keyboard(uint8_t l);
    virtual ~Keyboard();
    void setData(int8_t d);
    int8_t getData();
    void reset();
    int8_t other(int8_t b);
    void display(SDL_Renderer* render, uint16_t x, uint16_t y);
    void printInfo();

protected:

private:
    std::queue<char> *data;
    uint8_t length;

    void print_queue(std::queue<char> q);
};

#endif // KEYBOARD_H

#ifndef PORT_H
#define PORT_H


class PORT
{
    public:
        PORT();
        virtual ~PORT();

    protected:

    private:

};

#endif // PORT_H

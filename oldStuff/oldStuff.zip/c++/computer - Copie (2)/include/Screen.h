#ifndef SCREEN_H
#define SCREEN_H

#include <stdint.h>
#include "Device.h"

class Screen: public Device
{
public:
    Screen();
    virtual ~Screen();
    void setData(int8_t d);
    int8_t getData();
    void reset();
    int8_t other(int8_t b);
    void display(SDL_Renderer* render, uint16_t x, uint16_t y);
    void printInfo();

protected:

private:
    uint8_t **data;
    uint16_t resX;
    uint16_t resY;
    uint8_t drawRatio;
    uint8_t cache[2];
    uint8_t cacheCnt;
    bool refresh;
    uint8_t mode;

    uint8_t plt_16_r[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    uint8_t plt_16_g[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    uint8_t plt_16_b[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
};

#endif // SCREEN_H

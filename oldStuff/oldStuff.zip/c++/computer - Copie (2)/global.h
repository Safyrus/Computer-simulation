#ifndef GLOBAL_H
#define GLOBAL_H

extern bool print;
extern bool printInfo;
extern bool printFile;
extern bool refresh;

#endif // GLOBAL_H

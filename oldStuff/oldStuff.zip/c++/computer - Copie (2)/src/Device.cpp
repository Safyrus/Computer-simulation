#include "Device.h"

#include <stdint.h>

Device::Device()
{
    //ctor
}

Device::~Device()
{
    //dtor
}

#include "Keyboard.h"
#include "../global.h"
#include <stdint.h>
#include <stdio.h>
#include <queue>

Keyboard::Keyboard()
{
    if(print)
        printf("Keyboard: create...\n");
    length = 8;
    data = new std::queue<char>;
    if(print)
        printf("Keyboard: created\n");
}

Keyboard::Keyboard(uint8_t l)
{
    if(print)
        printf("Keyboard: create...\n");
    length = l;
    data = new std::queue<char>;
    if(print)
        printf("Keyboard: created\n");
}

Keyboard::~Keyboard()
{
    delete data;
    if(print)
        printf("Keyboard: destroyed\n");
}

void Keyboard::setData(int8_t d)
{
    if(data->size() < length)
        data->push(d);
}

int8_t Keyboard::getData()
{
    if(!data->empty())
    {
        int8_t d = data->front();
        data->pop();
        return d;
    }
    return 0;
}

void Keyboard::reset()
{
    while(!data->empty())
    {
        data->pop();
    }
}

int8_t Keyboard::other(int8_t b)
{
    return 0;
}

void Keyboard::printInfo()
{
    printf("keyboard: ");
    print_queue(*data);
}

void Keyboard::display(SDL_Renderer* render, uint16_t x, uint16_t y)
{

}

void Keyboard::print_queue(std::queue<char> q)
{
    while (!q.empty())
    {
        printf("%c ", q.front());
        q.pop();
    }
    printf("\n");
}

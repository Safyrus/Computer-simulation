#include <stdint.h>
#include <stdio.h>
#include <cmath>

#include "CPU.h"
#include "../global.h"

CPU::CPU()
{
    if(print)
        printf("CPU: create...\n");
    error = false;
    for(int i=0; i<8; i++)
    {
        reg[i] = 0;
        devices[i] = NULL;
    }
    //disk = new DISK("test.a");
    //ram = new RAM();
    if(print)
        printf("CPU: created\n");
}

CPU::CPU(char* file, uint32_t ram)
{
    if(print)
        printf("CPU: create...\n");
    error = false;
    for(int i=0; i<8; i++)
    {
        reg[i] = 0;
        devices[i] = NULL;
    }
    disk = new DISK(file);
    this->ram = new RAM(ram);
    if(print)
        printf("CPU: created\n");
}

CPU::~CPU()
{
    delete ram;
    delete disk;
    for(int i=0; i<8; i++)
    {
        if(devices[i] != NULL)
        {
            if(print)
                printf("DEVICES: remove device on port %d\n",i);
            delete devices[i];
        }
    }
    if(print)
        printf("DEVICES: destroyed\n");
    delete devices;
    if(print)
        printf("CPU: destroyed\n");

}

void CPU::tick()
{
    if(reg[7]<=0)
    {
        if(printInfo)
        {
            printf("DEVICES:\n");
            for(int i=0; i<8; i++)
            {
                if(devices[i] != NULL)
                {
                    devices[i]->printInfo();
                }
            }
            printf("BEFORE: reg: ");
            for(int i=0; i<8; i++)
            {
                printf("%02X ", reg[i] & 0xff);
            }
            printf("disk_adr: %02X ", disk->getAdr());
            printf("disk_data: %02X ", disk->getData());
            printf("ram_adr: %02X ", ram->getAdr());
            printf("\n");
        }
        reg[6] = ram->getData();
        int8_t e = CU(disk->getData());
        ram->setData(reg[6]);
        if(!error)
        {
            reg[7] = e;
            error = true;
        }
        if(printInfo)
        {
            printf("AFTER: reg: ");
            for(int i=0; i<8; i++)
            {
                printf("%02X ", reg[i] & 0xff);
            }
            printf("disk_adr: %02X ", disk->getAdr());
            printf("disk_data: %02X ", disk->getData());
            printf("ram_adr: %02X ", ram->getAdr());
            printf("\n");
        }
    }
}

void CPU::add_disk(DISK *d)
{
    disk = d;
    if(print)
        printf("CPU: disk added\n");
}

void CPU::remove_disk()
{
    disk = NULL;
    if(print)
        printf("CPU: disk removed\n");
}

void CPU::add_ram(RAM *r)
{
    ram = r;
    if(print)
        printf("CPU: ram added\n");
}

void CPU::remove_ram()
{
    ram = NULL;
    if(print)
        printf("CPU: ram removed\n");
}

void CPU::add_device(Device *d, uint8_t p)
{
    if(p < 8 && devices[p] == NULL)
    {
        devices[p] = d;
        printf("CPU: add device\n");
    }
}

void CPU::remove_device(uint8_t p)
{
    devices[p] = NULL;
}

int8_t CPU::getError()
{
    if(error)
    {
        error = false;
        return reg[7];
    }
    return 0;
}

void CPU::display(SDL_Renderer* render, uint16_t x, uint16_t y)
{
    for(int i=0; i<8; i++)
    {
        if(devices[i] != NULL)
        {
            devices[i]->display(render, x, y);
        }
    }
}


int8_t CPU::ALU(int8_t A, int8_t B, int8_t opcode)
{
    switch(opcode)
    {
    case 0:
        return A+B;
    case 1:
        return A-B;
    case 2:
        return A++;
    case 3:
        return A--;
    case 4:
        return A*B;
    case 5:
        return A/B;
    case 6:
        return A%B;
    case 7:
        return A<<B;
    case 8:
        return A>>B;
    case 9:
        return A&B;
    case 10:
        return A|B;
    case 11:
        return A^B;
    case 12:
        return ~A;
    default:
        return 0;
    }
}

int8_t CPU::CU(int8_t opcode)
{
    if (disk->length() < 0)
        return 1;
    switch(opcode)
    {
    case 0x00:
        return 3;
    case 0x01:
        disk->incAdr();
        return 0;
    case 0x02:
        return -1;
    case 0x03:
        return 4;
    case 0x04:
        return err();
    case 0x05:
        return oneOp(15);
    case 0x10:
        return regOp(13);
    case 0x11:
        return valOp(13);
    case 0x12:
        return diskOp(true, true);
    case 0x13:
        return diskOp(false, true);
    case 0x14:
        return diskOp(true, false);
    case 0x15:
        return diskOp(false, false);
    case 0x16:
        return adr(true);
    case 0x17:
        return adr(false);
    case 0x18:
        return go(true);
    case 0x19:
        return go(false);
    case 0x1A:
        return device();
    case 0x20:
        return jump(2);
    case 0x21:
        return jump(3);
    case 0x22:
        return jump(4);
    case 0x23:
        return jump(5);
    case 0x24:
        return jump(6);
    case 0x25:
        return jump(7);
    case 0x26:
        return jump(8);
    case 0x27:
        return jump(9);
    case 0x28:
        return jump(0);
    case 0x30:
        return jump(10);
    case 0x31:
        return jump(11);
    case 0x32:
        return jump(12);
    case 0x33:
        return jump(13);
    case 0x34:
        return jump(14);
    case 0x35:
        return jump(15);
    case 0x36:
        return jump(16);
    case 0x37:
        return jump(17);
    case 0x38:
        return jump(1);
    case 0x40:
        return regOp(0);
    case 0x41:
        return valOp(0);
    case 0x42:
        return regOp(1);
    case 0x43:
        return valOp(1);
    case 0x44:
        return regOp(4);
    case 0x45:
        return valOp(4);
    case 0x46:
        return regOp(5);
    case 0x47:
        return valOp(5);
    case 0x48:
        return regOp(6);
    case 0x49:
        return valOp(6);
    case 0x4A:
        return oneOp(2);
    case 0x4B:
        return oneOp(3);
    case 0x50:
        return regOp(9);
    case 0x51:
        return valOp(9);
    case 0x52:
        return regOp(10);
    case 0x53:
        return valOp(10);
    case 0x54:
        return regOp(11);
    case 0x55:
        return valOp(11);
    case 0x56:
        return oneOp(12);
    case 0x57:
        return regOp(8);
    case 0x58:
        return valOp(8);
    case 0x59:
        return regOp(7);
    case 0x5A:
        return valOp(7);
    case 0x60:
        return regOp(14);
    case 0x61:
        return valOp(14);
    }
    return 0;
}

int8_t CPU::err()
{
    disk->incAdr();
    int8_t e = disk->getData();
    disk->incAdr();
    return e;
}

int8_t CPU::regOp(int8_t op)
{
    disk->incAdr();
    int8_t a = disk->getData();
    if(a >= sizeof(reg))
        return -2;
    disk->incAdr();
    int8_t b = disk->getData();
    if(b >= sizeof(reg))
        return -2;
    if(a == 7)
    {
        disk->incAdr();
        return reg[b];
    }
    return moveOp(a, reg[b], op);
}

int8_t CPU::valOp(int8_t op)
{
    disk->incAdr();
    int8_t a = disk->getData();
    if (a >= sizeof(reg))
        return -2;
    disk->incAdr();
    int8_t b = disk->getData();
    if(a == 7 && op != 14)
    {
        disk->incAdr();
        return b;
    }
    return moveOp(a, b, op);
}

int8_t CPU::oneOp(int8_t op)
{
    disk->incAdr();
    int8_t a = disk->getData();
    if (a >= sizeof(reg))
        return -2;
    return moveOp(a, 0, op);
}

int8_t CPU::moveOp(int8_t a, int8_t b, int8_t op)
{
    switch(op)
    {
    case 2:
        reg[a]++;
        break;
    case 3:
        reg[a]--;
        break;
    case 0:
    case 1:
    case 4:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
        reg[a] = ALU(reg[a], b, op);
        break;
    case 5:
    case 6:
        if (b==0)
        {
            disk->incAdr();
            return -3;
        }
        reg[a] = ALU(reg[a], b, op);
        break;
    case 13:
        reg[a] = b;
        break;
    case 14:
        reg[5] = 0;
        reg[5] += ((uint8_t)(reg[a]+b)<(uint8_t)(reg[a])) ? 1 : 0;
        reg[5] += ((reg[a]+b) == 0) ? 2 : 0;
        reg[5] += (std::signbit(reg[a]+b) != std::signbit(reg[a])) ? 4 : 0;
        reg[5] += ((reg[a]+b) < 0) ? 8 : 0;
        //reg[5];  INTERUPT
        reg[5] += (reg[a] == b) ? 32 : 0;
        reg[5] += (reg[a] > b) ? 64 : 0;
        reg[5] += (reg[a] < b) ? 128 : 0;
        break;
    case 15:
        reg[a] = rand() % 256;
        break;
    }
    disk->incAdr();
    return 0;
}

int8_t CPU::jump(int8_t op)
{
    uint32_t jp = 0;
    uint32_t l = disk->length();
    uint32_t d = disk->getAdr();
    for (int i=l; i>0; i--)
    {
        disk->incAdr();
        uint32_t res = 0;
        res = disk->getData() << 24;
        jp += res >> (32-(i*8));
        printf("\n%x",jp);
    }
    jp += d;
    if((op == 1 || (op >= 10 && op <= 17)) && jp > disk->getDataSize())
    {
        jp %= disk->getDataSize();
    }
    printf("\n%x %x %x",jp,d,disk->getDataSize());
    switch(op)
    {
    case 0:
    case 1:
        disk->setAdr(jp);
        break;
    case 2:
    case 10:
        disk->setAdr(((reg[5]&1)==1)?jp:d+l+1);
        break;
    case 3:
    case 11:
        disk->setAdr(((reg[5]&2)==2)?jp:d+l+1);
        break;
    case 4:
    case 12:
        disk->setAdr(((reg[5]&4)==4)?jp:d+l+1);
        break;
    case 5:
    case 13:
        disk->setAdr(((reg[5]&8)==8)?jp:d+l+1);
        break;
    case 6:
    case 14:
        disk->setAdr(((reg[5]&16)==16)?jp:d+l+1);
        break;
    case 7:
    case 15:
        disk->setAdr(((reg[5]&32)==32)?jp:d+l+1);
        break;
    case 8:
    case 16:
        disk->setAdr(((reg[5]&64)==64)?jp:d+l+1);
        break;
    case 9:
    case 17:
        disk->setAdr(((reg[5]&128)==128)?jp:d+l+1);
        break;
    }
    return 0;
}

int8_t CPU::device()
{
    disk->incAdr();
    int8_t a = disk->getData();
    int8_t port = 0;
    int8_t r = a&7;
    switch(a&224)
    {
    case 0:
        port = 0;
        break;
    case 32:
        port = 1;
        break;
    case 64:
        port = 2;
        break;
    case 96:
        port = 3;
        break;
    case 128:
        port = 4;
        break;
    case 160:
        port = 5;
        break;
    case 192:
        port = 6;
        break;
    case 224:
        port = 7;
        break;
    }
    if(devices[port] == NULL)
    {
        disk->incAdr();
        return -4;
    }
    switch(a&24)
    {
    case 0:
        if (r < sizeof(reg))
            reg[r] = devices[port]->getData();
        break;
    case 8:
        if (r < sizeof(reg))
            devices[port]->setData(reg[r]);
        break;
    case 16:
        devices[port]->reset();
        break;
    case 24:
        if (r < sizeof(reg))
            reg[r] = devices[port]->other(reg[r]);
        break;
    }
    disk->incAdr();
    return 0;

}

int8_t CPU::diskOp(bool r, bool g)
{
    uint32_t get = 0;
    uint32_t l =disk->length();
    if(r)
    {
        for (int i=0; i<l; i++)
        {
            disk->incAdr();
            //printf("%i %i %i %i",l,disk->getData(),reg[disk->getData()],pow(256, l-i-1));
            get += reg[disk->getData()]*pow(256,l-i-1);
        }
    }
    else
    {
        for (int i=0; i<l; i++)
        {
            disk->incAdr();
            get += disk->getData()*pow(256, l-i-1);
        }
    }
    //printf("%u",get);
    disk->incAdr();
    int8_t re = disk->getData();
    disk->incAdr();
    if(re >= sizeof(reg))
    {
        return -2;
    }
    uint32_t preAdr = disk->getAdr();
    disk->setAdr(get);
    if(g)
        reg[re] = disk->getData();
    else
        disk->setData(reg[re]);
    disk->setAdr(preAdr);
    return 0;
}

int8_t CPU::adr(bool r)
{
    uint32_t a = 0;
    uint32_t l =ram->length();
    if(r)
    {
        for (int i=0; i<l; i++)
        {
            disk->incAdr();
            printf("%i %i %i %i",l,disk->getData(),reg[disk->getData()],pow(256, l-i-1));
            a += reg[disk->getData()]*pow(256,l-i-1);
        }
    }
    else
    {
        for (int i=0; i<l; i++)
        {
            disk->incAdr();
            a += disk->getData()*pow(256, l-i-1);
        }
    }
    printf("%u",a);
    ram->setAdr(a);
    reg[6] = ram->getData();
    disk->incAdr();
    return 0;
}

int8_t CPU::go(bool r)
{
    return 0x10;
}

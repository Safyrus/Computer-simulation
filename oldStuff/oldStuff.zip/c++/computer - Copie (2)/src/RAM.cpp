#include <stdint.h>
#include <stdio.h>

#include "RAM.h"
#include "../global.h"

RAM::RAM()
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = 256;
    len = 1;
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created\n");
}

RAM::RAM(uint32_t length)
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = length;
    setLen();
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created, bytes_length: %d\n", len);
}

RAM::~RAM()
{
    delete data;
    if(print)
        printf("RAM: destroyed\n");
}


uint32_t RAM::getAdr()
{
    return adr;
}

void RAM::setAdr(uint32_t a)
{
    adr = a;
}

int8_t RAM::getData()
{
    return data[adr];
}

void RAM::setData(int8_t d)
{
    data[adr] = d;
}

uint32_t RAM::length()
{
    return len;
}

void RAM::setLen()
{
    if(dataSize <= 256)
        len = 1;
    else if(dataSize <= 65536)
        len = 2;
    else if(dataSize <= 16777216)
        len = 3;
    else
        len = 4;
}

void RAM::incAdr()
{
    adr++;
}

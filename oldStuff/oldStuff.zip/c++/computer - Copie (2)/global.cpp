#include "global.h"

bool print = true;
bool printFile = true;
bool printInfo = true;
bool refresh = false;

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int write()
{

    ofstream monFlux("ASSEMBLER");

    if(monFlux)
    {
        monFlux << "hello" << endl;
        monFlux << 42.1337 << endl;
    }
    else
    {
        cout << "ERROR: File not found or cannot be opened." << endl;
    }
    return 0;
}

int main()
{
    string cells[65536];
    string opAss[64];
    opAss[0] = "NOP";
    opAss[1] = "NXT";
    opAss[2] = "RST";
    opAss[3] = "OFF";
    opAss[4] = "ER0";
    opAss[5] = "ER1";
    opAss[54] = "PRE";
    opAss[6] = "MOR";
    opAss[7] = "MOV";
    opAss[8] = "MRR";
    opAss[9] = "MRV";
    opAss[10] = "MVR";
    opAss[11] = "MVV";
    opAss[12] = "GET";
    opAss[13] = "SET";
    opAss[14] = "ADR";
    opAss[15] = "GO ";
    opAss[16] = "CAL";
    opAss[17] = "CPA";
    opAss[18] = "CPS";
    opAss[19] = "AJP";
    opAss[20] = "AJC";
    opAss[21] = "AJV";
    opAss[22] = "AJZ";
    opAss[23] = "AJS";
    opAss[24] = "AJE";
    opAss[25] = "RJP";
    opAss[26] = "RJC";
    opAss[27] = "RJV";
    opAss[28] = "RJZ";
    opAss[29] = "RJS";
    opAss[30] = "RJE";
    opAss[31] = "ADD";
    opAss[32] = "ADV";
    opAss[33] = "SUB";
    opAss[34] = "SUV";
    opAss[35] = "MUL";
    opAss[36] = "MUV";
    opAss[37] = "DIV";
    opAss[38] = "DVV";
    opAss[39] = "MOD";
    opAss[40] = "MDV";
    opAss[41] = "INC";
    opAss[42] = "DEC";
    opAss[43] = "AND";
    opAss[44] = "ANV";
    opAss[45] = "OR ";
    opAss[46] = "ORV";
    opAss[47] = "XOR";
    opAss[48] = "XOV";
    opAss[49] = "NOT";
    opAss[50] = "SHR";
    opAss[51] = "SHL";
    opAss[52] = "ROR";
    opAss[53] = "ROL";
    string opHex[64];
    opHex[0] = "0";
    opHex[1] = "1";
    opHex[2] = "2";
    opHex[3] = "3";
    opHex[4] = "4";
    opHex[5] = "5";
    opHex[6] = "10";
    opHex[7] = "11";
    opHex[8] = "12";
    opHex[9] = "13";
    opHex[10] = "14";
    opHex[11] = "15";
    opHex[12] = "16";
    opHex[13] = "17";
    opHex[14] = "18";
    opHex[15] = "19";
    opHex[16] = "1a";
    opHex[17] = "20";
    opHex[18] = "21";
    opHex[19] = "22";
    opHex[20] = "23";
    opHex[21] = "24";
    opHex[22] = "25";
    opHex[23] = "26";
    opHex[24] = "27";
    opHex[25] = "28";
    opHex[26] = "29";
    opHex[27] = "2a";
    opHex[28] = "2b";
    opHex[29] = "2c";
    opHex[30] = "2d";
    opHex[31] = "40";
    opHex[32] = "41";
    opHex[33] = "42";
    opHex[34] = "43";
    opHex[35] = "44";
    opHex[36] = "45";
    opHex[37] = "46";
    opHex[38] = "47";
    opHex[39] = "48";
    opHex[40] = "49";
    opHex[41] = "4a";
    opHex[42] = "4b";
    opHex[43] = "50";
    opHex[44] = "51";
    opHex[45] = "52";
    opHex[46] = "53";
    opHex[47] = "54";
    opHex[48] = "55";
    opHex[49] = "56";
    opHex[50] = "57";
    opHex[51] = "58";
    opHex[52] = "59";
    opHex[53] = "5a";
    opHex[54] = "6";
    unsigned int counter = 0;

    ofstream fileHex("PRAM");
    ifstream fileAss("ASSEMBLER");

    if(fileHex && fileAss)
    {
        string line;
        fileHex << "v2.0 raw" << endl;
        while(getline(fileAss, line))
        {
            try{
                cout << line << endl;
                string code = line.substr(0,3);
                int codeNum = -1;
                for(unsigned int i=0; i<sizeof(opAss); i++){
                    if(code.compare(opAss[i]) == 0){
                        codeNum = i;
                        break;
                    }
                }
                if(codeNum > -1){
                    fileHex << opHex[codeNum] + " ";
                        //cout << "++" << endl;
                        counter++;
                    if(counter > 7){
                        //cout << "endl" << endl;
                        fileHex << endl;
                        counter = 0;
                    }else{
                    }
                    unsigned int j = 0;
                    try{
                        while(j<2){
                            fileHex << line.substr(4+j*3,2) + " ";
                                //cout << "++" << endl;
                                counter++;
                            if(counter > 7){
                                //cout << "endl" << endl;
                                fileHex << endl;
                                counter = 0;
                            }else{
                            }
                            j++;
                        }
                    }catch(const out_of_range& oor){
                    }
                }else{
                    cout << "! INSTRUCTION NOT FOUND !" << endl;
                }
            }catch(const out_of_range& oor){
            }
        }
    }
    else
    {
        cout << "ERROR: Files not found or cannot be opened." << endl;
    }
    return 0;
}

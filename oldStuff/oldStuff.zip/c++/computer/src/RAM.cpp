#include <stdint.h>
#include <stdio.h>
#include <SDL.h>
#include <SDL_ttf.h>

#include "RAM.h"
#include "Text.h"
#include "../global.h"

RAM::RAM()
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = 256;
    len = 1;
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created\n");
}

RAM::RAM(uint32_t length)
{
    if(print)
        printf("RAM: create...\n");
    adr = 0;
    dataSize = length;
    setLen();
    data = new int8_t[dataSize];
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
    if(print)
        printf("RAM: created, bytes_length: %d\n", len);
}

RAM::~RAM()
{
    delete data;
    if(print)
        printf("RAM: destroyed\n");
}


uint32_t RAM::getAdr()
{
    return adr;
}

void RAM::setAdr(uint32_t a)
{
    adr = a;
}

int8_t RAM::getData()
{
    return data[adr];
}

void RAM::setData(int8_t d)
{
    data[adr] = d;
}

uint32_t RAM::length()
{
    return len;
}

void RAM::setLen()
{
    if(dataSize <= 256)
        len = 1;
    else if(dataSize <= 65536)
        len = 2;
    else if(dataSize <= 16777216)
        len = 3;
    else
        len = 4;
}

void RAM::incAdr()
{
    adr++;
}

void RAM::reset()
{
    adr = 0;
    for(int i=0; i<dataSize; i++)
        data[i] = 0;
}

void RAM::display(SDL_Renderer* render, uint16_t x, uint16_t y, uint32_t page)
{
    uint32_t p = page*256;

    float textRatio = 16;

    /*SDL_SetRenderDrawColor(render, 0x00, 0x00, 0xFF, 0xFF);
    SDL_Rect background = {x, y, 16*textRatio*1.4, 16*textRatio+20};
    SDL_RenderFillRect( render, &background );*/

    char s[48];
    sprintf(s, "RAM:    PAGE:%X0", p & 0xff);

    Text txt;
    txt.drawRect(render, x, y, 16*textRatio*1.7, 16*textRatio+20, 255, 0, 0);
    txt.setColor(255,255,255);
    txt.loadText(render, s);
    txt.render(render,x,y);
    y += 20;

    for(uint32_t i=p; i<p+256; i+=16)
    {
        uint32_t j=i;
        sprintf(s, "%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",
        data[j] & 0xff, data[j+1] & 0xff, data[j+2] & 0xff, data[j+3] & 0xff, data[j+4] & 0xff, data[j+5] & 0xff, data[j+6] & 0xff, data[j+7] & 0xff,
        data[j+8] & 0xff, data[j+9] & 0xff, data[j+10] & 0xff, data[j+11] & 0xff, data[j+12] & 0xff, data[j+13] & 0xff, data[j+14] & 0xff, data[j+15] & 0xff);
        txt.setColor(255,255,255);
        txt.loadText(render, s);
        txt.render(render, x+((j%16)*(textRatio*1.4)), y+((i%256)*(textRatio/16)));
    }
}

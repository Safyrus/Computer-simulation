#include "Computer.h"
#include "Text.h"
#include "../global.h"
#include <SDL.h>

Computer::Computer()
{
    if(print)
        printf("COMPUTER: create...\n");
    run = false;
    cycle = 0;
    Hz = 4;
    fps = 4;
    cpu = new CPU();
    ram = new RAM(256);
    disk = new DISK("test.a");
    cpu->add_disk(disk);
    cpu->add_ram(ram);
    if(print)
        printf("COMPUTER: created\n");
}

Computer::Computer(char* s, uint32_t hz, int fps)
{
    if(print)
        printf("COMPUTER: create...\n");
    run = false;
    cycle = 0;
    Hz = hz;
    if(fps <= 0)
        this->fps = 1;
    else if(fps > Hz)
        this->fps = Hz;
    else
        this->fps = fps;
    cpu = new CPU();
    ram = new RAM(256);
    disk = new DISK(s);
    cpu->add_disk(disk);
    cpu->add_ram(ram);
    if(print)
        printf("COMPUTER: created\n");
}

Computer::~Computer()
{
    cpu->remove_disk();
    cpu->remove_ram();
    delete ram;
    delete disk;
    delete cpu;
    if(print)
        printf("COMPUTER: destroyed\n");
}


void Computer::power()
{
    run = !run;
    if(print)
    {
        printf("\x1b[93m\x1b[49m");
        printf("COMPUTER: power %s", (run)?"ON":"OFF");
        printf("\x1b[0m\n");
    }
    if(!run)
    {
        reset();
    }
}

bool Computer::isPower()
{
    return run;
}

void Computer::reset()
{
    cycle = 0;
    cpu->reset();
}

void Computer::tick()
{
    if(run)
    {
        for(int i=0; i<Hz/fps; i++)
        {
            cpu->tick();
            cycle++;
            int8_t e = cpu->getError();
            if(e <= 0)
            {
                if(e < 0 && print)
                {
                    printf("\x1b[91m\x1b[49m");
                    printf("COMPUTER: error %d at cycle %u", e, cycle);
                    printf("\x1b[0m\n");
                }
                if(printInfo)
                    printf("COMPUTER: tick %u\n", cycle);
            }
            else
            {
                if(e == 4)
                {
                    if(print)
                        printf("COMPUTER: stop at cycle %u\n", cycle);
                }
                else
                {
                    if(print)
                    {
                        printf("\x1b[97m\x1b[101m");
                        printf("COMPUTER: fatal error %d at cycle %u", e, cycle);
                        printf("\x1b[0m\n");
                    }
                }
                power();
                if(print)
                {
                    printf("\x1b[93m\x1b[49m");
                    printf("COMPUTER: power %s", (run)?"ON":"OFF");
                    printf("\x1b[0m\n");
                }
            }
        }
    }
}

void Computer::add_device(Device *d, uint8_t p)
{
    cpu->add_device(d, p);
}

void Computer::remove_device(uint8_t p)
{
    cpu->remove_device(p);
}

void Computer::display(SDL_Window* win, SDL_Renderer* render, uint16_t x, uint16_t y)
{
    Text txt;

    //SDL_SetRenderDrawColor(render, 0xFF, 0xFF, 0xFF, 0xFF);
    //SDL_Rect rect = {x, y+380, 320, 132};
    //SDL_RenderFillRect(render, &rect);
    txt.drawRect(render, x, y+380, 320, 200, 128,128,128);

    char s[50];
    sprintf(s, "power:%s", (run)?"ON":"OFF");

    txt.setColor(255,255,255);
    txt.loadText(render, s);
    txt.render(render, x+20, y+400);

    //rect = {x, y+380, 320, 132};
    //SDL_RenderFillRect(render, &rect);

    sprintf(s, "fps: %u, Hz:%u", fps, Hz);
    txt.loadText(render, s);
    txt.render(render, x+20, y+416);

    sprintf(s, "cycle:%u", cycle);
    txt.loadText(render, s);
    txt.render(render, x+20, y+432);

    cpu->display(render, x, y);
}

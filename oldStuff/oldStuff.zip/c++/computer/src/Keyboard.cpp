#include "Keyboard.h"
#include "Text.h"
#include "../global.h"
#include <stdint.h>
#include <string>
#include <array>
#include <stdio.h>
#include <SDL.h>
#include <queue>

Keyboard::Keyboard()
{
    if(print)
        printf("Keyboard: create...\n");
    length = 8;
    data = new std::queue<char>;
    if(print)
        printf("Keyboard: created\n");
}

Keyboard::Keyboard(uint8_t l)
{
    if(print)
        printf("Keyboard: create...\n");
    length = l;
    data = new std::queue<char>;
    if(print)
        printf("Keyboard: created\n");
}

Keyboard::~Keyboard()
{
    delete data;
    if(print)
        printf("Keyboard: destroyed\n");
}

void Keyboard::setData(int8_t d)
{
    if(data->size() < length)
        data->push(d);
}

int8_t Keyboard::getData()
{
    if(!data->empty())
    {
        int8_t d = data->front();
        data->pop();
        return d;
    }
    return 0;
}

void Keyboard::reset()
{
    while(!data->empty())
    {
        data->pop();
    }
}

int8_t Keyboard::other(int8_t b)
{
    return 0;
}

void Keyboard::printInfo()
{
    printf("keyboard: ");
    print_queue(*data);
}

void Keyboard::display(SDL_Renderer* render, uint16_t x, uint16_t y)
{
    /*SDL_SetRenderDrawColor(render, 0x00, 0xFF, 0x00, 0xFF);
    SDL_Rect background = {x, y, 320, 60};
    SDL_RenderFillRect(render, &background);*/

    char s[length*2];
    for(int i=0, j=0; i<length*2; i+=2, j++)
    {
        s[i] = get_char(*data, j);
        s[i+1] = ' ';
    }

    Text txt;
    txt.drawRect(render, x, y, 320, 60, 0, 255, 0);
    txt.setColor(255,255,255);
    txt.loadText(render, s);
    txt.render(render, x+20, y+20);
}

void Keyboard::print_queue(std::queue<char> q)
{
    while (!q.empty())
    {
        printf("%c ", q.front());
        q.pop();
    }
    printf("\n");
}

char Keyboard::get_char(std::queue<char> q, int n)
{
    char c = ' ';
    int i=0;
    while (!q.empty())
    {
        if(n == i)
            c = q.front();
        q.pop();
        i++;
    }
    return c;
}

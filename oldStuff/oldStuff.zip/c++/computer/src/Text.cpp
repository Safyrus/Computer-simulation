#include "Text.h"

Text::Text()
{
    texture = NULL;
    font = NULL;
    color = {0,0,0};
    int width = 0;
    int height = 0;
}

Text::~Text()
{
    free();
}

void Text::free()
{
    if(texture != NULL)
    {
        SDL_DestroyTexture(texture);
        texture = NULL;
    }
    if(font != NULL)
    {
        TTF_CloseFont(font);
        font = NULL;
    }
}

bool Text::loadText(SDL_Renderer* render, std::string text)
{
    free();

    font = TTF_OpenFont("Perfect DOS VGA 437 Win.ttf", 16);
    if(font == NULL)
    {
        printf("Error: could not load font! SDL_ttf Error: %s\n", TTF_GetError());
        return false;
    }

    SDL_Surface* surf = TTF_RenderText_Solid(font,text.c_str(),color);
    if(surf == NULL)
    {
        printf( "Error: could not render text surface! SDL_ttf Error: %s\n", TTF_GetError());
        return false;
    }

    texture = SDL_CreateTextureFromSurface(render, surf);
    if(texture == NULL)
    {
        printf( "Error: could not create texture! SDL Error: %s\n", SDL_GetError());
        return false;
    }

    width = surf->w;
    height = surf->h;

    SDL_FreeSurface(surf);

    return true;
}

void Text::drawRect(SDL_Renderer* render, int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b)
{
    SDL_Surface *surf = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
    SDL_FillRect(surf, NULL, SDL_MapRGB(surf->format, r, g, b));
    SDL_Texture* texture = SDL_CreateTextureFromSurface(render, surf);
    SDL_Rect rect = {x,y,w,h};
    SDL_RenderCopy(render, texture, NULL, &rect);
    SDL_FreeSurface(surf);
    SDL_DestroyTexture(texture);
}

void Text::setColor(Uint8 red, Uint8 green, Uint8 blue)
{
    color = {red, green, blue};
}

void Text::render(SDL_Renderer* render, int x, int y)
{
    SDL_Rect rect = {x,y,width,height};
    SDL_RenderCopy(render, texture, NULL, &rect);
}

int Text::getWidth()
{
    return width;
}

int Text::getHeight()
{
    return height;
}

#ifndef TEXT_H
#define TEXT_H

#include <string>
#include <SDL.h>
#include <SDL_ttf.h>

class Text
{
public:
    Text();
    ~Text();

    bool loadText(SDL_Renderer* render, std::string text);
    void free();
    void setColor(Uint8 red, Uint8 green, Uint8 blue);
    void render(SDL_Renderer* render, int x, int y);
    void drawRect(SDL_Renderer* render, int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b);

    int getWidth();
    int getHeight();

private:
    SDL_Texture* texture;
    SDL_Color color;
    TTF_Font* font;

    int width;
    int height;
};

#endif
